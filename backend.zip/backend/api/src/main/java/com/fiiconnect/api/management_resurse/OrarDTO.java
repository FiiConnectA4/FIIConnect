package com.fiiconnect.api.management_resurse;

public class OrarDTO {
    private String zi;
    private String interval;
    private String disciplina;
    private String tip;
    private String grupa;
    private String sala;
    private String profesor;
    private String an; 
    private Integer id;
   

    public OrarDTO(String zi, String interval, String disciplina, String tip, String grupa, String sala, String profesor, String an, Integer id) {
        this.zi = zi;
        this.interval = interval;
        this.disciplina = disciplina;
        this.tip = tip;
        this.grupa = grupa;
        this.sala = sala;
        this.profesor = profesor;
        this.an = an;
        this.id = id;
    }

    // Getters
    public String getZi() { return zi; }
    public String getInterval() { return interval; }
    public String getDisciplina() { return disciplina; }
    public String getTip() { return tip; }
    public String getGrupa() { return grupa; }
    public String getSala() { return sala; }
    public String getProfesor() {
        return profesor;
    }
    public String getAn() { return an; } 
    public Integer getId() { return id; } 
  
}
